-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- ホスト: myapp-db
-- 生成日時: 2021 年 4 月 12 日 02:58
-- サーバのバージョン： 8.0.23
-- PHP のバージョン: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- データベース: `sampledb`
--

-- --------------------------------------------------------

--
-- テーブルの構造 `likes`
--

CREATE TABLE `likes` (
  `id` int NOT NULL,
  `task_id` int NOT NULL,
  `user_id` int NOT NULL,
  `created` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- テーブルのデータのダンプ `likes`
--

INSERT INTO `likes` (`id`, `task_id`, `user_id`, `created`) VALUES
(1, 1, 2, '2021-04-07 15:54:36'),
(3, 2, 3, '2021-04-07 15:58:25'),
(5, 3, 3, '2021-04-07 15:58:38'),
(6, 4, 4, '2021-04-07 16:01:50'),
(7, 4, 5, '2021-04-07 16:02:07'),
(8, 4, 6, '2021-04-07 16:04:50'),
(9, 1, 6, '2021-04-07 16:04:53'),
(10, 7, 7, '2021-04-07 16:06:07'),
(11, 9, 8, '2021-04-07 16:07:24'),
(12, 1, 9, '2021-04-07 16:09:59'),
(13, 6, 9, '2021-04-07 16:10:02'),
(14, 11, 10, '2021-04-07 16:15:21');

-- --------------------------------------------------------

--
-- テーブルの構造 `roles`
--

CREATE TABLE `roles` (
  `id` int NOT NULL,
  `name` varchar(10) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- テーブルのデータのダンプ `roles`
--

INSERT INTO `roles` (`id`, `name`) VALUES
(1, '一般'),
(2, '管理者');

-- --------------------------------------------------------

--
-- テーブルの構造 `tasks`
--

CREATE TABLE `tasks` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `title` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `content` varchar(1000) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- テーブルのデータのダンプ `tasks`
--

INSERT INTO `tasks` (`id`, `user_id`, `title`, `content`, `created`, `modified`) VALUES
(1, 1, 'ダイエット', '夏までに痩せる!', '2021-04-07 15:46:41', '2021-04-09 22:55:12'),
(2, 2, '貯金', 'お酒を控えて毎月1万円ためる！', '2021-04-07 15:55:56', '2021-04-07 15:55:56'),
(3, 3, '毎日勉強する', '大学に合格するため、苦手分野を毎朝勉強。\r\nさぼり厳禁', '2021-04-07 15:58:06', '2021-04-07 15:58:06'),
(4, 4, '早起きする', '早起きは三文の徳', '2021-04-07 16:01:46', '2021-04-07 16:01:46'),
(6, 5, '積みゲーを消化する', '休みを使って、積みゲーを消化!', '2021-04-07 16:04:19', '2021-04-07 16:04:19'),
(7, 6, '今シーズンはダイヤにいく！', '', '2021-04-07 16:04:44', '2021-04-07 16:04:44'),
(8, 7, 'じょいふぁおい', 'ｓぢおふぁじょいじょ', '2021-04-07 16:05:46', '2021-04-07 16:05:46'),
(9, 8, 'スイーツ巡り！！', '週末は友達とスイーツ巡りにいきます！', '2021-04-07 16:07:20', '2021-04-07 16:07:20'),
(10, 9, 'テスト', 'aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa', '2021-04-07 16:08:13', '2021-04-07 16:08:13'),
(11, 10, 'aaaaaaaaaaa', 'aaaaaaaaaaaaaaa', '2021-04-07 16:12:16', '2021-04-07 16:13:14');

-- --------------------------------------------------------

--
-- テーブルの構造 `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `role_id` int NOT NULL DEFAULT '1',
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- テーブルのデータのダンプ `users`
--

INSERT INTO `users` (`id`, `role_id`, `username`, `password`, `created`, `modified`) VALUES
(1, 1, 'test1', '$2y$10$iFGQMIFu.zUGgXdnhD4aGO1lAQOnLaAhrCAjG0JyZqo8NTlHVMday', '2021-04-07 15:18:26', '2021-04-07 15:18:26'),
(2, 1, 'test2', '$2y$10$39rWu0jA0beQcr0PartVe.uGbixNlR/i.i6S7CL6yA.vC1sB5UNRG', '2021-04-07 15:25:58', '2021-04-07 15:25:58'),
(3, 1, 'test3', '$2y$10$60bjAXokodBQIry/QXKk7.iksumBNNXatRLZISUK56Cs43.CZCi92', '2021-04-07 15:54:15', '2021-04-07 15:54:15'),
(4, 1, 'test4', '$2y$10$WDsibhPdvgur50MoOThi.uRCcIoanENULsUhxe/wOYF31/qBtlY2a', '2021-04-07 15:59:11', '2021-04-07 15:59:11'),
(5, 1, 'test5', '$2y$10$sfJXImt0p588NgAtDlCJbutZXcg3KB0apJeUA67VHwkXqQTBNW0/.', '2021-04-07 15:59:18', '2021-04-07 15:59:18'),
(6, 1, 'test6', '$2y$10$P/ncW6I.dqHM4psCSQTgvOHll2NMvXPgFxjlPzf.n1WdfTHWg9ur2', '2021-04-07 15:59:23', '2021-04-07 15:59:23'),
(7, 1, 'test7', '$2y$10$2jc2ywPCMWuPOc6Qst1LWeJVIJhzPAus3SvjgTh9EtBMof0VSyFl.', '2021-04-07 15:59:29', '2021-04-07 15:59:29'),
(8, 1, 'test8', '$2y$10$JKutJtjkHAzDnM7nzO/1uevC1eajBXJ5Pj36uUfiVUX0K0eHoILlC', '2021-04-07 15:59:34', '2021-04-07 15:59:34'),
(9, 1, 'test9', '$2y$10$FJLyxD9nqfptRnlFBZlctOgB2WjfOr8OEhdZXA9r11KXUl8S2VwLC', '2021-04-07 15:59:41', '2021-04-07 15:59:41'),
(10, 1, 'test10', '$2y$10$IyfakbJ5SAUdGXqP9QZ1m.QKney3qHiwpxIVYpWYh1k1AtDDQm1Y6', '2021-04-07 15:59:46', '2021-04-07 15:59:46'),
(11, 2, 'admin1', '$2y$10$y42WTNHUQvI8vTXF6v/zBO2MdxxmOO8KjDN5koq6230uXL7ZMfNyq', '2021-04-09 22:55:57', '2021-04-09 22:55:57');

--
-- ダンプしたテーブルのインデックス
--

--
-- テーブルのインデックス `likes`
--
ALTER TABLE `likes`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- テーブルのインデックス `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- ダンプしたテーブルの AUTO_INCREMENT
--

--
-- テーブルの AUTO_INCREMENT `likes`
--
ALTER TABLE `likes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- テーブルの AUTO_INCREMENT `roles`
--
ALTER TABLE `roles`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- テーブルの AUTO_INCREMENT `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- テーブルの AUTO_INCREMENT `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
